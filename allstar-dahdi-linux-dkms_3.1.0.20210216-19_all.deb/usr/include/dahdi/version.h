/*
 * version.h
 * Automatically generated
 */
#define DAHDI_VERSION "3.1.0"

